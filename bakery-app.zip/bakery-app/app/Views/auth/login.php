<?php

use App\Helpers\ViewHelper;

$title = $data['title'] ?? 'Login';
$identifier = $data['identifier'] ?? '';
ViewHelper::loadHeader($title);
?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Login</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="<?= APP_BASE_URL ?>/login">
                    <div class="mb-3">
                        <label for="identifier" class="form-label">Email or Username</label>
                        <input
                            type="text"
                            class="form-control"
                            id="identifier"
                            name="identifier"
                            value="<?= hs($identifier) ?>"
                            placeholder="Enter your email or username"
                            required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input
                            type="password"
                            class="form-control"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            required>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>

                <div class="mt-3 text-center">
                    <p>Don't have an account? <a href="<?= APP_BASE_URL ?>/register">Register here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php ViewHelper::loadFooter(); ?>
